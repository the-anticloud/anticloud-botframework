# 01 Investor Package

**Project:** BOTFRAMEWORK
**Upstream:** https://github.com/nicedoc/botframework

Content specific to BOTFRAMEWORK in category CHAT_PLATFORMS.
